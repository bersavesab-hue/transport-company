export interface AssetDefinition {
  id: string;
  path: string | null;
  fallback: string;
  width: number;
  height: number;
  category: "brand" | "map" | "vehicle" | "cargo" | "facility" | "portrait";
  status: "fallback" | "final";
}

const mapBaseSatelliteUrl = new URL("../../assets/generated/map-base-satellite-0002.png", import.meta.url).href;
const mapRegionHeyueYunzeUrl = new URL("../../assets/generated/map-region-heyue-yunze-0003.png", import.meta.url).href;
const mapCountyFuchuanUrl = new URL("../../assets/generated/map-county-fuchuan-0004.png", import.meta.url).href;
const mapLocalFuchuanUrl = new URL("../../assets/generated/map-local-fuchuan-0005.png", import.meta.url).href;
const brandLogoUrl = new URL("../../assets/generated/brand_logo_001-0001.webp", import.meta.url).href;
const vehicleLightTruckUrl = new URL("../../assets/generated/vehicle_light_truck_001-0001.webp", import.meta.url).href;
const vehicleMicroVanUrl = new URL("../../assets/generated/vehicle_micro_van_001-0001.webp", import.meta.url).href;
const vehicleMediumTruckUrl = new URL("../../assets/generated/vehicle_medium_truck_001-0001.webp", import.meta.url).href;
const vehicleHeavyTruckUrl = new URL("../../assets/generated/vehicle_heavy_truck_001-0001.webp", import.meta.url).href;
const vehicleRefrigeratedUrl = new URL("../../assets/generated/vehicle_refrigerated_001-0001.webp", import.meta.url).href;
const cargoGeneralUrl = new URL("../../assets/generated/cargo_general_001-0001.webp", import.meta.url).href;
const cargoElectronicsUrl = new URL("../../assets/generated/cargo_electronics_001-0001.webp", import.meta.url).href;
const cargoFurnitureUrl = new URL("../../assets/generated/cargo_furniture_001-0001.webp", import.meta.url).href;
const cargoFreshFoodUrl = new URL("../../assets/generated/cargo_fresh_food_001-0001.webp", import.meta.url).href;
const cargoAutoPartsUrl = new URL("../../assets/generated/cargo_auto_parts_001-0001.webp", import.meta.url).href;
const cargoExpressUrl = new URL("../../assets/generated/cargo_express_001-0001.webp", import.meta.url).href;
const facilityHqSmallUrl = new URL("../../assets/generated/facility_hq_small_001-0001.webp", import.meta.url).href;
const facilityParkingSmallUrl = new URL("../../assets/generated/facility_parking_small_001-0001.webp", import.meta.url).href;

export const ASSET_CATALOG: readonly AssetDefinition[] = [
  { id: "brand_logo_001", path: brandLogoUrl, fallback: "route", width: 512, height: 512, category: "brand", status: "final" },
  { id: "map_region_central_china_001", path: null, fallback: "map", width: 1600, height: 1200, category: "map", status: "fallback" },
  { id: "map_china_national_001", path: null, fallback: "map", width: 4096, height: 2304, category: "map", status: "fallback" },
  { id: "map_world_terrain_001", path: null, fallback: "map", width: 1536, height: 1024, category: "map", status: "fallback" },
  { id: "map_world_satellite_002", path: mapBaseSatelliteUrl, fallback: "map", width: 990, height: 1584, category: "map", status: "final" },
  { id: "map_world_region_detail_003", path: mapRegionHeyueYunzeUrl, fallback: "map", width: 992, height: 1586, category: "map", status: "final" },
  { id: "map_world_county_detail_004", path: mapCountyFuchuanUrl, fallback: "map", width: 992, height: 1586, category: "map", status: "final" },
  { id: "map_world_local_detail_005", path: mapLocalFuchuanUrl, fallback: "map", width: 992, height: 1585, category: "map", status: "final" },
  { id: "vehicle_light_truck_001", path: vehicleLightTruckUrl, fallback: "truck", width: 768, height: 384, category: "vehicle", status: "final" },
  { id: "vehicle_micro_van_001", path: vehicleMicroVanUrl, fallback: "truck", width: 768, height: 384, category: "vehicle", status: "final" },
  { id: "vehicle_medium_truck_001", path: vehicleMediumTruckUrl, fallback: "truck", width: 768, height: 384, category: "vehicle", status: "final" },
  { id: "vehicle_heavy_truck_001", path: vehicleHeavyTruckUrl, fallback: "truck", width: 768, height: 384, category: "vehicle", status: "final" },
  { id: "vehicle_refrigerated_001", path: vehicleRefrigeratedUrl, fallback: "truck", width: 768, height: 384, category: "vehicle", status: "final" },
  { id: "cargo_general_001", path: cargoGeneralUrl, fallback: "box", width: 192, height: 192, category: "cargo", status: "final" },
  { id: "cargo_electronics_001", path: cargoElectronicsUrl, fallback: "chip", width: 192, height: 192, category: "cargo", status: "final" },
  { id: "cargo_furniture_001", path: cargoFurnitureUrl, fallback: "chair", width: 192, height: 192, category: "cargo", status: "final" },
  { id: "cargo_fresh_food_001", path: cargoFreshFoodUrl, fallback: "fresh", width: 192, height: 192, category: "cargo", status: "final" },
  { id: "cargo_auto_parts_001", path: cargoAutoPartsUrl, fallback: "gear", width: 192, height: 192, category: "cargo", status: "final" },
  { id: "cargo_express_001", path: cargoExpressUrl, fallback: "parcel", width: 192, height: 192, category: "cargo", status: "final" },
  { id: "facility_hq_small_001", path: facilityHqSmallUrl, fallback: "building", width: 512, height: 512, category: "facility", status: "final" },
  { id: "facility_parking_small_001", path: facilityParkingSmallUrl, fallback: "parking", width: 512, height: 512, category: "facility", status: "final" }
] as const;

export const getAsset = (id: string) => ASSET_CATALOG.find((asset) => asset.id === id);
