const paths: Record<string, string> = {
  map: '<path d="M3 6.5 8 4l8 3 5-2.5v13L16 20l-8-3-5 2.5z"/><path d="M8 4v13M16 7v13"/>',
  orders: '<path d="M7 3h10v4H7z"/><path d="M5 5H3v16h18V5h-2M8 12h8M8 16h5"/>',
  truck: '<path d="M3 6h11v11H3zM14 10h4l3 3v4h-7z"/><circle cx="7" cy="18" r="2"/><circle cx="18" cy="18" r="2"/>',
  company: '<path d="M4 21V8l8-5 8 5v13M9 21v-6h6v6M8 10h1M15 10h1"/>',
  more: '<circle cx="5" cy="12" r="1"/><circle cx="12" cy="12" r="1"/><circle cx="19" cy="12" r="1"/>',
  box: '<path d="m4 7 8-4 8 4-8 4zM4 7v10l8 4 8-4V7M12 11v10"/>',
  arrow: '<path d="M5 12h14M14 7l5 5-5 5"/>',
  news: '<path d="M4 5h16v14H4zM8 9h8M8 13h5"/><path d="M2 8v9a2 2 0 0 0 2 2"/>',
  route: '<path d="M5 20c0-7 4-8 7-8s7-1 7-8"/><circle cx="5" cy="20" r="2"/><circle cx="19" cy="4" r="2"/><path d="m9 8 3-3 3 3"/>',
  chip: '<rect x="6" y="6" width="12" height="12" rx="2"/><path d="M9 9h6v6H9zM9 2v4M15 2v4M9 18v4M15 18v4M2 9h4M2 15h4M18 9h4M18 15h4"/>',
  chair: '<path d="M7 12V5a3 3 0 0 1 6 0v7M5 12h11a3 3 0 0 1 3 3v2H5zM7 17v4M17 17v4"/>',
  fresh: '<path d="M12 21c-5-3-7-7-7-11 4 0 7 2 7 6 0-5 3-8 7-9 0 6-2 11-7 14Z"/><path d="M12 16c0-5 0-8 3-12"/>',
  gear: '<circle cx="12" cy="12" r="3"/><path d="M12 2v3M12 19v3M2 12h3M19 12h3M4.9 4.9 7 7M17 17l2.1 2.1M19.1 4.9 17 7M7 17l-2.1 2.1"/>',
  parcel: '<path d="m4 7 8-4 8 4v10l-8 4-8-4zM4 7l8 4 8-4M12 11v10M8 5l8 4"/>',
  building: '<path d="M4 21V6l8-3 8 3v15M8 8h2M14 8h2M8 12h2M14 12h2M9 21v-5h6v5"/>',
  parking: '<rect x="3" y="3" width="18" height="18" rx="3"/><path d="M9 17V7h4a3 3 0 0 1 0 6H9M9 13h4"/>'
};

export const icon = (name: string, className = "icon"): string =>
  `<svg class="${className}" viewBox="0 0 24 24" aria-hidden="true" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round">${paths[name] ?? paths.box}</svg>`;
